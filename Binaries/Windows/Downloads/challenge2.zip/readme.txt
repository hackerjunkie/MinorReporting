Deploy with ncat -klnvp <port> -e <path to netservice.exe>

Connect to the service with ncat <host> <port>

Localhost connections are fine