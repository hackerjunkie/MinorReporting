python2 -m pip install --upgrade pwntools
python exploit_dungeon5_template.py
